<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 

function castUTF8($text){
      $fileEndEnd = mb_convert_encoding($text, 'HTML-ENTITIES', "UTF-8");
    return html_entity_decode($fileEndEnd);
// mb_convert_encoding($text, 'Windows-1252', 'UTF-8');
 }

if(isset($_GET["search"])){
$conn = new PDO(
    'mysql:host=mysql.hostinger.com;dbname=u915481333_torre', 'u915481333_torre', 'ana010118',
    array(
        PDO::ATTR_PERSISTENT => true
    )
);  
    
$query = trim($_GET["search"]);  
$limit_de = "0" ;
$limit_ate  = "500";
    
    
    if(isset($_GET["limit_de"])){
      $limit_de = $_GET["limit_de"];
    }
    if(isset($_GET["limit_ate"])){
     $limit_ate = $_GET["limit_ate"];
   }
     
$sth = $conn->prepare("SELECT *, COUNT(title) AS episodios FROM videos where title like  '%".$query."%' GROUP BY title LIMIT ".$limit_de.", ".$limit_ate);
$sth->execute(); 
$result = $sth->fetchAll(\PDO::FETCH_ASSOC); 
     
 $re3 = '{"result":'.json_encode($result, JSON_PRETTY_PRINT ).'}';
 echo $re3;
    
}



if(isset($_GET["serie_item"])){
$conn = new PDO(
    'mysql:host=mysql.hostinger.com;dbname=u915481333_torre', 'u915481333_torre', 'ana010118',
    array(
        PDO::ATTR_PERSISTENT => true
    )
);  
   $query = trim($_GET["serie_item"]);   
     
$commandd= "SELECT *, category AS episodios FROM videos where trim(title) = '".$query."'";
$sth = $conn->prepare($commandd);
$sth->execute(); 
$result = $sth->fetchAll(\PDO::FETCH_ASSOC); 
     
 $re3 = '{"result":'.json_encode($result, JSON_PRETTY_PRINT ).'}';
 echo $re3;
    
}



if(isset($_GET["series"])){
$conn = new PDO(
    'mysql:host=mysql.hostinger.com;dbname=u915481333_torre', 'u915481333_torre', 'ana010118',
    array(
        PDO::ATTR_PERSISTENT => true
    )
);  
    
$query = trim($_GET["series"]);  
    $limit_de = "0" ;
$limit_ate  = "20";
    
    
    if(isset($_GET["limit_de"])){
      $limit_de = $_GET["limit_de"];
    }
    if(isset($_GET["limit_ate"])){
     $limit_ate = $_GET["limit_ate"];
   }
    
$sth = $conn->prepare("  SELECT title, COUNT(title)  AS total   FROM videos where title like  '%".$query."%' or description like  '%".$query."%'  GROUP BY title LIMIT ".$limit_de.", ".$limit_ate);
$sth->execute(); 
$result = $sth->fetchAll(\PDO::FETCH_ASSOC);
echo json_encode($result, JSON_PRETTY_PRINT );
    
}


if(isset($_GET["promo"])){
$conn = new PDO(
    'mysql:host=mysql.hostinger.com;dbname=u915481333_torre', 'u915481333_torre', 'ana010118',
    array(
        PDO::ATTR_PERSISTENT => true
    )
);   
    
$sth = $conn->prepare(" SELECT * from promo where status = 1");
$sth->execute(); 
$result = $sth->fetchAll(\PDO::FETCH_ASSOC);
echo json_encode($result, JSON_PRETTY_PRINT );
    
}


